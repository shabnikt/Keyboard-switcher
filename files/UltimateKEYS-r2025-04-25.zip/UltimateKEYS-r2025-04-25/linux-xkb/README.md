# UltimateKEYS - XKB integration (Linux)

## Integration in GNU/Linux via XKB (X11)

- Put the file "custom" into "/usr/share/X11/xkb/symbols/" (root required).
- Activate the layout on your desktop via the keyboard settings by selecting "A user-defined custom Layout".

## Keyboard Layout Image

![UltimateKEYS - Keyboard Layout Image](/images/UltimateKEYS%20-%20Keyboard%20Layout%20Image.png)
