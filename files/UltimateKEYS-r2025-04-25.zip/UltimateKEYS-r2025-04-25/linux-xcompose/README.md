# UltimateKEYS - Compose Key Sequences (Linux)

To apply the additional Compose Key sequences, put the file ".XCompose" into the user's home directory (~).

Note that the base keyboard layout should also be added via either XKB or Xmodmap to enable the layout on Linux.
